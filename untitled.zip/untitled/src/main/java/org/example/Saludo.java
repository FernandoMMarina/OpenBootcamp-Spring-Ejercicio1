package org.example;

public class Saludo {

    public String imprimirSaludo(){
        return "Hola Compi";
    }
}
